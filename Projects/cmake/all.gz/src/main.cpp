#include <stdio.h>
int main()
{
	printf("dddd");
}
